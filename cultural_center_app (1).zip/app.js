// استرجاع البيانات من LocalStorage عند فتح الصفحة
let students = JSON.parse(localStorage.getItem('center_students_data')) || [];

const studentForm = document.getElementById('studentForm');
const studentTableBody = document.getElementById('studentTableBody');

studentForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const total = parseFloat(document.getElementById('totalFee').value) || 0;
    const paid = parseFloat(document.getElementById('paidFee').value) || 0;

    const newStudent = {
        id: Date.now(),
        name: document.getElementById('studentName').value.trim(),
        nationalId: document.getElementById('nationalId').value.trim(),
        phone: document.getElementById('studentPhone').value.trim(),
        subject: document.getElementById('subject').value,
        teacher: document.getElementById('teacher').value,
        totalFee: total,
        paidFee: paid,
        remainingFee: Math.max(0, total - paid),
        attendance: { present: 0, absent: 0 }
    };

    students.push(newStudent);
    saveAndRender();
    studentForm.reset();
});

function saveAndRender() {
    localStorage.setItem('center_students_data', JSON.stringify(students));
    renderStudents();
    updateStats();
}

function renderStudents() {
    studentTableBody.innerHTML = '';
    
    if (students.length === 0) {
        studentTableBody.innerHTML = `
            <tr>
                <td colspan="6" class="p-8 text-center text-slate-400 font-medium">
                    لا يوجد طلاب مسجلون حالياً. قم بإضافة طالب جديد من النموذج أعلاه.
                </td>
            </tr>
        `;
        return;
    }

    students.forEach((s, index) => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-slate-50/80 transition duration-150';
        
        const isPaidFully = s.remainingFee === 0;

        tr.innerHTML = `
            <td class="p-4">
                <div class="font-bold text-slate-900">${s.name}</div>
                <div class="text-xs text-slate-500 font-mono mt-0.5">🪪 ${s.nationalId} | 📞 ${s.phone}</div>
            </td>
            <td class="p-4">
                <span class="inline-block bg-blue-50 text-blue-700 font-semibold px-2.5 py-1 rounded-md text-xs border border-blue-100">
                    ${s.subject}
                </span>
                <div class="text-xs text-slate-500 mt-1">${s.teacher}</div>
            </td>
            <td class="p-4">
                <div class="text-emerald-600 font-bold text-xs">مدفوع: ${s.paidFee} د.أ</div>
                <div class="${isPaidFully ? 'text-slate-400 line-through' : 'text-rose-600'} text-xs font-semibold mt-0.5">
                    متبقي: ${s.remainingFee} د.أ
                </div>
            </td>
            <td class="p-4">
                <button onclick="payInstallment(${index})" class="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold px-3 py-1.5 rounded-lg text-xs transition border border-emerald-200 flex items-center gap-1">
                    <span>💵</span> دفع قسط
                </button>
            </td>
            <td class="p-4">
                <div class="flex items-center gap-2">
                    <button onclick="markAttendance(${index}, 'present')" class="bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold px-2.5 py-1 rounded-lg text-xs border border-blue-200 transition">
                        حضور (${s.attendance.present})
                    </button>
                    <button onclick="markAttendance(${index}, 'absent')" class="bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold px-2.5 py-1 rounded-lg text-xs border border-rose-200 transition">
                        غياب (${s.attendance.absent})
                    </button>
                </div>
            </td>
            <td class="p-4 text-center">
                <button onclick="deleteStudent(${index})" class="text-slate-400 hover:text-rose-600 transition p-1 text-base" title="حذف الطالب">
                    🗑️
                </button>
            </td>
        `;
        studentTableBody.appendChild(tr);
    });
}

function payInstallment(index) {
    const amount = prompt(`أدخل قيمة القسط المدفوع للطالب (${students[index].name}):`);
    if (amount !== null && !isNaN(amount) && parseFloat(amount) > 0) {
        const val = parseFloat(amount);
        students[index].paidFee += val;
        students[index].remainingFee = Math.max(0, students[index].totalFee - students[index].paidFee);
        saveAndRender();
    }
}

function markAttendance(index, type) {
    if (type === 'present') students[index].attendance.present++;
    if (type === 'absent') students[index].attendance.absent++;
    saveAndRender();
}

function deleteStudent(index) {
    if (confirm(`هل أنت تأكد من حذف الطالب (${students[index].name})؟`)) {
        students.splice(index, 1);
        saveAndRender();
    }
}

function updateStats() {
    document.getElementById('totalStudents').innerText = students.length;
    document.getElementById('studentCountBadge').innerText = `${students.length} طالب`;

    const paid = students.reduce((sum, s) => sum + s.paidFee, 0);
    const remaining = students.reduce((sum, s) => sum + s.remainingFee, 0);

    document.getElementById('totalPaid').innerText = paid + " د.أ";
    document.getElementById('totalRemaining').innerText = remaining + " د.أ";
}

// التشغيل المبدئي عند التحميل
renderStudents();
updateStats();
